#pragma once
#include <string>
#include <iostream>
#include "Date.h"
#include "Coordinate.h"
using namespace std;

class Graph {
    public:
    Graph(int day, string month, int year);
    void addPoint(int x = 0, int y = 0);
    void saveToFile(ofstream& outFile);
    
    private:
    int pointCount;
    Coordinate points[100];
    Date graphDate;
};
