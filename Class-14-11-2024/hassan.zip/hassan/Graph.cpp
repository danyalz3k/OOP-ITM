#include "Date.h"
#include "Coordinate.h"
#include "Graph.h"
#include <fstream>
#include <iostream>
using namespace std;

Graph::Graph(int day, string month, int year) : graphDate(day, month, year) {
    pointCount = 0;
}

void Graph::addPoint(int x, int y) {
    if (pointCount < 100) {
        points[pointCount].setX(x);
        points[pointCount].setY(y);
        pointCount++;
    }
}

void Graph::saveToFile(ofstream& outFile) {
    graphDate.saveToFile(outFile);
    for (int i = 0; i < pointCount; i++) {
        points[i].saveToFile(outFile);
    }
}
