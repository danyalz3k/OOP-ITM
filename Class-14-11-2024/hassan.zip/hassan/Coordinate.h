#include <string>
#include <iostream>
using namespace std;

class Coordinate {
    public:
    Coordinate();
    void setX(int newX);
    void setY(int newY);
    void saveToFile(ofstream& outFile);

    private:
    int xCoord;
    int yCoord;
};
