#include "Coordinate.h"
#include <fstream>
#include <iostream>
using namespace std;

Coordinate::Coordinate() {
    xCoord = 0;
    yCoord = 0;
}

void Coordinate::setX(int newX) {
    xCoord = newX;
}

void Coordinate::setY(int newY) {
    yCoord = newY;
}

void Coordinate::saveToFile(ofstream& outFile) {
    outFile << "(" << xCoord << "," << yCoord << ")" << endl;
}
