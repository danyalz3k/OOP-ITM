#pragma once
#include <string>
#include <iostream>
using namespace std;

class Date {
    public:
    Date(int day, string month, int year);
    void saveToFile(ofstream& outFile);
    
    private:
    int day;
    string month;
    int year;
};
