#include "Date.h"
#include <fstream>
#include <iostream>
using namespace std;

Date::Date(int day, string month, int year) {
    this->day = day;
    this->month = month;
    this->year = year;
}

void Date::saveToFile(ofstream& outFile) {
    outFile << day << " " << month << " " << year << endl;
}
